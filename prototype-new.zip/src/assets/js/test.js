function loadingDynamically(){
  //alert("loaded test.js")
  console.log("loaded external file");
}
loadingDynamically();
